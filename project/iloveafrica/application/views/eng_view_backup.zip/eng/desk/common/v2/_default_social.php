<a href="https://www.youtube.com/user/IloveafricaNGO" class="ic_ut" target="_blank"><span class="blind">Youtube</span></a>
<a href="https://www.facebook.com/ngoiloveafrica/" class="ic_fb" target="_blank"><span class="blind">FaceBook</span></a>
<a href="https://www.instagram.com/ngoiloveafrica/" class="ic_in" target="_blank"><span class="blind">Instagram</span></a>
<a href="http://blog.naver.com/iloveafrica1" class="ic_nb" target="_blank"><span class="blind">Naver Blog</span></a>
<a href="https://post.naver.com/iloveafrica1" class="ic_np" target="_blank"><span class="blind">Naver Post</span></a>
<a href="http://www.twitter.com/ngoiloveafrica" class="ic_tw" target="_blank"><span class="blind">Twitter</span></a>