
<?php include APPPATH."views/mobile/news/sub_tab.php"; ?>
<div class="sub_cont_c">
    <div class="sub_title">아이러브아프리카 특별자료</div>
    <div id="issuu" class="issuu_wrap">
        <iframe src="https://e.issuu.com/embed.html?identifier=4avjsqrfx9l4&embedType=script#15812229/54168489" id="ifrIssuu" name="ifrIssuu" frameborder="0" width="880" height="550" title="issuu.com" frameborder="0" allowfullscreen="true"></iframe>
    </div>

    <div class="select_pub">
        <select name="selIssuu" id="selIssuu">
            <option value="https://e.issuu.com/embed.html?identifier=4avjsqrfx9l4&embedType=script#15812229/54168489">2017 단체소개서 (국문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=u9whr5suwc4h&embedType=script#15812229/58856889">2017 단체소개서 (영문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=uhk13d1wemxk&embedType=script#15812229/58850315">2017 연차보고서 (국문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=zn2fc8veg9g8&embedType=script#15812229/58852169">2016 연차보고서 (국문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=zjuv5fixxilb&embedType=script#15812229/54643014">2016 연차보고서 (영문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=hgmxvomuvata&embedType=script#15812229/34893423">2015 연차보고서 (국문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=uqus6wnnl92n&embedType=script#15812229/36455072">2015 연차보고서 (영문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=fjufvlx3bive&embedType=script#15812229/34893303">2014 연차보고서 (국문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=e38mvwfwybi1&embedType=script#15812229/34893414">2014 연차보고서 (영문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=4lprv0pwf2j7&embedType=script#15812229/41256279">2013 연차보고서 (국문)</option>
            <option value="https://e.issuu.com/embed.html?identifier=1a71xi1qxjtf&embedType=script#0/34869161">2013 연차보고서 (영문)</option>
        </select>
    </div>
    <br /><br />
    <div class="bg_line"></div>

    <div class="sub_title">아이러브아프리카 CI 다운로드</div>
    <div class="img_area" style="padding:10%"><img src="/assets/images/mobile/img_s3_4.png" alt=""></div>
    <div class="ci_download">
        <a href="http://iloveafrica.or.kr/down/logo.ai" class="b1">AI 파일 다운로드 <em class="ic">⬇</em></a>
        <a href="http://iloveafrica.or.kr/down/logo.zip" class="b2">JPG 파일 다운로드 <em class="ic">⬇</em></a>
    </div>
    
</div>
