function Coins() {
  return <div>Coins</div>;
}

export default Coins;
