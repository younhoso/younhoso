<?php include APPPATH."views/$nation/mobile/support/sub_tab.php"; ?>
<div class="sub_cont_c">
	
	<div class="tab_d3">
		<ul id="t3">
			<li class="on"><a href="#ta1">사업후원 소개</a></li>
			<li><a href="#ta2">사업후원하기</a></li>
			<li><a href="#ta3">협력기업현황</a></li>
		</ul>
	</div>
	
	<div class="m_cont" id="ta1">
		<div class="m_img"><img src="/assets/images/mobile/img_s4_6_1.jpg" alt=""></div>
		<div class="m_txt">
			<p>
				<strong>기업의 아프리카 사랑 나눔, 그 사랑은 다시 우리 기업에 돌아옵니다.</strong>
			</p>
			<p>현대사회의 기업들은 기업의 단순 이윤 창출을 넘어 기업의 사회적 책임(Corporate Social Responsibility, CSR), 즉 직원과 가족, 지역사회, 국가를 아우르는 사회공헌활동에 초점을 맞추고 있습니다. 기업의 사회공헌 활동은 소비자들에게 기업 이미지의 긍정적인 제고와 이윤 창출에 직접적인 영향을 미치며, 이는 사회에 대한 환원 뿐 아니라 기업이 사회적 공공성, 윤리성 등을 적극적으로 실현하는 것을 의미합니다. 아이러브아프리카의 기업후원은 후원기업이 기업의 특성에 맞는 다양한 방법을 통해 전문적이고 차별화 된 방법으로 아프리카 대륙에 지속적인 사랑나눔 운동을 실천함으로 지역사회와 세계에 더 가까이 다가설 수 있게 하며, 이는 기업의 지속적인 성장에 기틀이 될 것입니다.</p>
			<br>
			
			<div class="bg_line"></div>
			<br><br>
			<div class="thmb_area">
				<div class="tit">후원방법</div>
				<dl class="thmb_lst">
					<dt><img src="/assets/images/mobile/img_s4_6_2.jpg" alt=""></dt>
					<dd>
						<p class="ic4_2_1">
							<span class="tt">기업기금후원</span>
							<span>후원기업 총 수익금의 일부나 특정제품 판매금의 일부를 <br />아이러브아프리카에 후원하시는 방법입니다.</span>
						</p>
					</dd>
				</dl>
				<dl class="thmb_lst">
					<dt><img src="/assets/images/mobile/img_s4_6_3.jpg" alt=""></dt>
					<dd>
						<p class="ic4_2_2">
							<span class="tt">임직원 “Lucky day” 후원</span>
							<span>후원기업의 임직원분들 모두가 매 월 급여일, 혹은 특정한 “럭키데이”를  정하셔서 일정금액을 아이러브아프리카에 정기후원 하시는 후원방법으로 임직원 모두가 후원에 동참하실 수 있습니다.</span>
						</p>
					</dd>
				</dl>
				<dl class="thmb_lst">
					<dt><img src="/assets/images/mobile/img_s4_6_4.jpg" alt=""></dt>
					<dd>
						<p class="ic4_2_3">
							<span class="tt">이벤트 후원</span>
							<span>후원기업의 특정제품 판매 등 이벤트 주최를 통해 판매 수익금을 아이러브 아프리카에 후원하시는 방법입니다. 기업의 상품을 구매하는 고객들은 해당 상품을 구매함으로 자연스럽게 기업의 사회공헌활동을 인지할 수 있게 됩니다.</span>
						</p>
					</dd>
				</dl>
				<dl class="thmb_lst">
					<dt><img src="/assets/images/mobile/img_s4_6_5.jpg" alt=""></dt>
					<dd>
						<p class="ic4_2_4">
							<span class="tt">사랑이나눔이 저금통후원</span>
							<span>NGO아이러브아프리카의 사랑이 나눔이 저금통을 후원기업의 사무실, 전국과 전 세계 매장에 설치하여 임직원과 고객들의 작은 정성들을 모아 후원하실 수 있는 방법입니다.</span>
						</p>
					</dd>
				</dl>
				<dl class="thmb_lst">
					<dt><img src="/assets/images/mobile/img_s4_6_6.jpg" alt=""></dt>
					<dd>
						<p class="ic4_2_4">
							<span class="tt">방송협찬후원</span>
							<span>TV방송매체로 아프리카의 실상을 전 세계에 알리는 아이러브아프리카의 사업을 후원하시는 방법입니다. 아이러브아프리카가 제작하는 TV프로그램에 기업 광고를 노출함으로 시청자들에게 기업을 홍보하고 사회공헌 기업의 이미지를 인지시킬 수 있습니다.</span>
						</p>
					</dd>
				</dl>
				<dl class="thmb_lst">
					<dt><img src="/assets/images/mobile/img_s4_6_7.jpg" alt=""></dt>
					<dd>
						<p class="ic4_2_4">
							<span class="tt">기업물품후원</span>
							<span>후원기업이 생산하는 특정제품이나 물품을 후원하실 수 있습니다.</span>
						</p>
					</dd>
				</dl>
				<dl class="thmb_lst">
					<dt><img src="/assets/images/mobile/img_s4_6_8.jpg" alt=""></dt>
					<dd>
						<p class="ic4_2_4">
							<span class="tt">아프리카 봉사원정대</span>
							<span>후원기업의 임직원분들이 휴가나 MT를 NGO아이러브아프리카의 아프리카 사업장으로 봉사활동을 가셔서 현장을 직접 도우실 수 있는 후원방법입니다.</span>
						</p>
					</dd>
				</dl>
			</div>
			
			<div class="btn_btm">
				<a href="<?php echo SUPPORT_ENTERPRISE_URL; ?>" target="<?php echo SUPPORT_ENTERPRISE_TARGET; ?>">기업후원 문의하기 &gt;</a>
			</div>

			<br /><br />
			<div class="bg_line"></div>
			<br />

			<div class="alt_cont">
				<div class="tit">단체기부에 참여하시면</div>
				<dl class="ic4_5_1">
					<dt>감사장</dt>
					<dd>10만 원 이상 후원자에게<br>원하는 단체명으로<br>감사장을 보내드립니다.</dd>
				</dl>
				<dl class="ic4_5_2">
					<dt>사진</dt>
					<dd>기부하신 후원금으로<br>이루어진 사업 사진을<br>보내드립니다.</dd>
				</dl>
			</div>

			<br /><br />

		</div>
	</div>

	<div class="m_cont" id="ta2" style="display:none">
		<div class="m_img"><img src="/assets/images/mobile/img_s4_6_1.jpg" alt=""></div>
		<div class="m_txt">
			<p>
				<strong>기업의 아프리카 사랑 나눔, 그 사랑은 다시 우리 기업에 돌아옵니다.</strong>
			</p>
			<p>현대사회의 기업들은 기업의 단순 이윤 창출을 넘어 기업의 사회적 책임(Corporate Social Responsibility, CSR), 즉 직원과 가족, 지역사회, 국가를 아우르는 사회공헌활동에 초점을 맞추고 있습니다. 기업의 사회공헌 활동은 소비자들에게 기업 이미지의 긍정적인 제고와 이윤 창출에 직접적인 영향을 미치며, 이는 사회에 대한 환원 뿐 아니라 기업이 사회적 공공성, 윤리성 등을 적극적으로 실현하는 것을 의미합니다. 아이러브아프리카의 기업후원은 후원기업이 기업의 특성에 맞는 다양한 방법을 통해 전문적이고 차별화 된 방법으로 아프리카 대륙에 지속적인 사랑나눔 운동을 실천함으로 지역사회와 세계에 더 가까이 다가설 수 있게 하며, 이는 기업의 지속적인 성장에 기틀이 될 것입니다.</p>
			<br>
			
			<div class="bg_line"></div>
			<br><br>
			<div class="thmb_area">
				<div class="tit">후원방법</div>
				<div class="img"><img src="/assets/images/mobile/img_s4_6_9.png" alt="후원방법" /></div>
			</div>

			<br><br>
			
			<div class="bg_line"></div>
			<br>

			<div class="thmb_area">
				<div class="tit" style="color:#2FC25B">기금 후원</div>
				<dl class="dlt">
					<dt><span>정기후원</span></dt>
					<dd>
						후원을 원하시는 아이러브아프리카의 사업을 
						매월 1만 원 이상씩 정기적으로 후원하는 방식입니다.
						후원은 CMS자동이체, 휴대폰, 신용카드, 
						무통장 입금 등으로 가능합니다. <br />
						(※ 단, 아프리카 아동후원의 금액은 매월 3만 원입니다.)
					</dd>
				</dl>
				<dl class="dlt">
					<dt><span style="background-color:#FFCC00">일시후원</span></dt>
					<dd>
						원하시는 일정 금액을 후원을 원하시는 아이러브아프리카의 
						사업에 일시적으로 후원하실 수 있는 방법입니다. <br />
						후원은 휴대폰, 신용카드, 무통장 입금 등으로 가능합니다.
					</dd>
				</dl>
			</div>
			
			<div class="btn_btm">
				<a href="<?php echo SUPPORT_ENTERPRISE_URL; ?>" target="<?php echo SUPPORT_ENTERPRISE_TARGET; ?>">기업후원 문의하기 &gt;</a>
			</div>

			

			<br /><br />

		</div>
	</div>

	<div class="m_cont" id="ta3" style="display:none">
		<div class="m_img"><img src="/assets/images/mobile/img_s4_6_1.jpg" alt=""></div>
		<div class="m_txt">
			
			<p>
				<strong>GOING <em style="color:#FF432F;font-weight:600">TOGETHER</em></strong>
			</p>
			
			<div class="bg_line"></div>

			<ul class="together_lst">
				<li><div class="thmb"><img src="/assets/images/mobile/img_together1.png" alt="" /></div><div class="tx">외교부</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together2.png" alt="" /></div><div class="tx">기획재정부</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together3.png" alt="" /></div><div class="tx">제네시스비비큐</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together4.png" alt="" /></div><div class="tx">한국국제협력단</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together5.png" alt="" /></div><div class="tx">한국수출입은행</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together6.png" alt="" /></div><div class="tx">한국교육문화진흥원</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together7.png" alt="" /></div><div class="tx">대신증권</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together8.png" alt="" /></div><div class="tx">NH농협금융</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together9.png" alt="" /></div><div class="tx">국민일보</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together10.png" alt="" /></div><div class="tx">한・아프리카재단</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together11.png" alt="" /></div><div class="tx">한국예탁결제원</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together12.png" alt="" /></div><div class="tx">CBS 기독교방송</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together13.png" alt="" /></div><div class="tx">한양대학교</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together14.png" alt="" /></div><div class="tx">CTS기독교TV</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together15.png" alt="" /></div><div class="tx">WBC복지TV</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together16.png" alt="" /></div><div class="tx">삼성물산</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together17.png" alt="" /></div><div class="tx">건국대학교</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together18.png" alt="" /></div><div class="tx">법무법인 바른</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together19.png" alt="" /></div><div class="tx">법무법인 세종</div></li>
				<li><div class="thmb"><img src="/assets/images/mobile/img_together20.png" alt="" /></div><div class="tx">(주)쇼노트</div></li>
			</ul>
			
			<div class="btn_btm">
				<a href="<?php echo SUPPORT_ENTERPRISE_URL; ?>" target="<?php echo SUPPORT_ENTERPRISE_TARGET; ?>">기업후원 문의하기 &gt;</a>
			</div>

			

			<br /><br />

		</div>
	</div>

</div>
<script>
$(document).ready(function(){
	$('#t3').on('click','a',function (e) {
		e.preventDefault();
		$('.m_cont').hide();
		$($(this).attr('href')).show();
		$('#t3 > li').removeClass('on');
		$(this).parent().addClass('on');
	});
});
</script>