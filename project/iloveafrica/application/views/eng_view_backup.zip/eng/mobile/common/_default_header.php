<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta name="format-detection" content="telephone=no">
<title>NGO I love AFRICA</title>
<link rel="stylesheet" type="text/css" href="/assets/css/mobile/common.css" />
<script type="text/javascript" src="/assets/js/jquery-3.2.1.min.js"></script>
</head>
<body>

<div class="wrap">