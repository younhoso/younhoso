<!DOCTYPE html>
<!-- saved from url=(0044)https://hwangsc.github.io/ila/html/home.html -->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ko" lang="ko"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>NGO I love AFRICA</title>
<link rel="stylesheet" type="text/css" href="/assets/css/desk/common.css">
<script type="text/javascript" src="/assets/js/jquery-3.2.1.min.js"></script>
</head>
<body>
<div id="skip">
	<ul>
		<li><a href="https://hwangsc.github.io/ila/html/home.html#header" onclick="document.getElementById(&#39;header&#39;).tabIndex = -1;document.getElementById(&#39;header&#39;).focus();return false;">카테고리 메뉴 바로가기</a></li>
		<li><a href="https://hwangsc.github.io/ila/html/home.html#container" onclick="document.getElementById(&#39;container&#39;).tabIndex = -1;document.getElementById(&#39;container&#39;).focus();return false;">본문바로가기</a></li>
	</ul>
</div>

<div id="wrap">