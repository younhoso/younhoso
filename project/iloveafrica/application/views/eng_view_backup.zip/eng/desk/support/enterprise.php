<div id="container">
		<div class="sub_tit">
			<h1>아이러브아프리카(ILA)<strong>・후원하기</strong></h1>
		</div>
		<div class="sub_cont">
			<div class="h_desc">
				아이러브아프리카는 아프리카 대륙을 전문으로 돕는 <br />
				<strong>아프리카전문국제구호개발 비정부기구</strong><br />
				<strong>(NGO, Non Governmental Organization)</strong>입니다.
			</div>
			<?php include APPPATH."views/$nation/desk/support/tab.php"; ?>
			<div class="sub_cont_s">
				<div class="m_left">
					<h3>기업후원</h3>
					<?php include APPPATH."views/$nation/desk/support/enterprise_tab.php"; ?>
				</div>
				<div class="m_cont">
					<div class="m_img"><img src="/assets/images/desk/img_s4_6_1.jpg" alt=""></div>
					<div class="m_txt">
						<p>
							<strong>기업의 아프리카 사랑 나눔, 그 사랑은 다시 우리 기업에 돌아옵니다.</strong>
						</p>
						<p>현대사회의 기업들은 기업의 단순 이윤 창출을 넘어 기업의 사회적 책임(Corporate Social Responsibility, CSR), 즉 직원과 가족, 지역사회, 국가를 아우르는 사회공헌활동에 초점을 맞추고 있습니다. 기업의 사회공헌 활동은 소비자들에게 기업 이미지의 긍정적인 제고와 이윤 창출에 직접적인 영향을 미치며, 이는 사회에 대한 환원 뿐 아니라 기업이 사회적 공공성, 윤리성 등을 적극적으로 실현하는 것을 의미합니다. 아이러브아프리카의 기업후원은 후원기업이 기업의 특성에 맞는 다양한 방법을 통해 전문적이고 차별화 된 방법으로 아프리카 대륙에 지속적인 사랑나눔 운동을 실천함으로 지역사회와 세계에 더 가까이 다가설 수 있게 하며, 이는 기업의 지속적인 성장에 기틀이 될 것입니다. </p>
						<br />
						
						<div class="line"></div>
						
						<div class="thmb_area">
							<div class="tit">후원방법</div>
							<dl class="thmb_lst">
								<dt><img src="/assets/images/desk/img_s4_6_2.jpg" alt="" /></dt>
								<dd>
									<p class="ic4_6_1">
										<span class="tt">기업기금후원</span>
										<span>후원기업 총 수익금의 일부나 특정제품 판매금의 일부를 <br />아이러브아프리카에 후원하시는 방법입니다.</span>
									</p>
								</dd>
							</dl>
							<dl class="thmb_lst">
								<dt><img src="/assets/images/desk/img_s4_6_3.jpg" alt="" /></dt>
								<dd>
									<p class="ic4_6_2">
										<span class="tt">임직원 “Lucky day” 후원</span>
										<span>후원기업의 임직원분들 모두가 매 월 급여일, 혹은 특정한 “럭키데이”를 정하셔서 <br />일정금액을 아이러브아프리카에 정기후원 하시는 후원방법으로 임직원 모두가 후원에 <br />동참하실 수 있습니다.</span>
									</p>
								</dd>
							</dl>
							<dl class="thmb_lst">
								<dt><img src="/assets/images/desk/img_s4_6_4.jpg" alt="" /></dt>
								<dd>
									<p class="ic4_6_3">
										<span class="tt">이벤트 후원</span>
										<span>후원기업의 특정제품 판매 등 이벤트 주최를 통해 판매 수익금을 아이러브 아프리카에 <br />후원하시는 방법입니다. 기업의 상품을 구매하는 고객들은 해당 상품을 구매함으로 <br />자연스럽게 기업의 사회공헌활동을 인지할 수 있게 됩니다.</span>
									</p>
								</dd>
							</dl>
							<dl class="thmb_lst">
								<dt><img src="/assets/images/desk/img_s4_6_5.jpg" alt="" /></dt>
								<dd>
									<p class="ic4_6_4">
										<span class="tt">사랑이나눔이 저금통후원</span>
										<span>NGO아이러브아프리카의 사랑이 나눔이 저금통을 후원기업의 사무실, 전국과 전 세계 <br />매장에 설치하여 임직원과 고객들의 작은 정성들을 모아 후원하실 수 있는 방법입니다.</span>
									</p>
								</dd>
							</dl>
							<dl class="thmb_lst">
								<dt><img src="/assets/images/desk/img_s4_6_6.jpg" alt="" /></dt>
								<dd>
									<p class="ic4_6_5">
										<span class="tt">방송협찬후원</span>
										<span>
										TV방송매체로 아프리카의 실상을 전 세계에 알리는 아이러브아프리카의 사업을 <br />
										후원하시는 방법입니다. 아이러브아프리카가 제작하는 TV프로그램에 기업 광고를 <br />
										노출함으로 시청자들에게 기업을 홍보하고 사회공헌 기업의 이미지를 인지시킬 수 <br />
										있습니다.</span>
									</p>
								</dd>
							</dl>
							<dl class="thmb_lst">
								<dt><img src="/assets/images/desk/img_s4_6_7.jpg" alt="" /></dt>
								<dd>
									<p class="ic4_6_6">
										<span class="tt">기업물품후원</span>
										<span>후원기업이 생산하는 특정제품이나 물품을 후원하실 수 있습니다.</span>
									</p>
								</dd>
							</dl>
							<dl class="thmb_lst">
								<dt><img src="/assets/images/desk/img_s4_6_8.jpg" alt="" /></dt>
								<dd>
									<p class="ic4_6_7">
										<span class="tt">아프리카 봉사원정대</span>
										<span>후원기업의 임직원분들이 휴가나 MT를 NGO아이러브아프리카의 아프리카 사업장으로 <br />봉사활동을 가셔서 현장을 직접 도우실 수 있는 후원방법입니다.</span>
									</p>
								</dd>
							</dl>
						</div>
						
						<div class="btn_btm">
							<a style="cursor:pointer" onclick="popView('<?php echo SUPPORT_ENTERPRISE_URL; ?>');">기업후원 문의하기 &gt;</a>
						</div>
						
						<br /><br />
						<div class="line"></div>
						<div class="alt_cont">
							<div class="tit">단체기부에 참여하시면</div>
							<dl class="ic4_5_1">
								<dt>감사장</dt>
								<dd>&middot; 10만 원 이상 후원자에게 원하는 단체명으로 감사장을 보내드립니다.</dd>
							</dl>
							<dl class="ic4_5_2">
								<dt>사진</dt>
								<dd>&middot; 기부하신 후원금으로 이루어진 사업 사진을 보내드립니다.</dd>
							</dl>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>