<div id="header">
<div class="header_top">
			<div class="header_top_in">
				<h1 class="logo_header"><a href="/<?= $nationlink ?>"><img src="/assets/images/desk/logo_header3.png" alt="NGO I LOVE AFRICA"></a></h1>
				<div class="link">
                    <a href="<? echo SUPPORT_MY; ?>" target="<? echo SUPPORT_MY_TARGET; ?>">나의 후원정보</a>
                    <span class="bar">|</span>
                    <a href="<?php echo SUPPORT_REGULAR_URL; ?>" target="<?php echo SUPPORT_REGULAR_TARGET; ?>">후원신청 및 회원가입</a>
                    <span class="bar">|</span>
                    <a href="/">KOREAN</a>
                    <?/*
                    <span class="bar">|</span>
                    <a href="#">ENGLISH</a>
                    */?>
				</div>
			</div>
		</div>
    <div class="header_gnb">
        <div class="header_gnb_in">
            <ul class="nav" id="nav">
                <li>
                    <a href="/index.php/<?= $nationlink ?>foundation/about" class="d1">재단소개</a>
                    <ul class="nav_sub">
                        <li><a href="/index.php/<?= $nationlink ?>foundation/about">ILA는?</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>foundation/history">연혁 비전</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>foundation/vision">핵심가치</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>foundation/greetings">인사말</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>foundation/way">찾아오시는 길</a></li>
                    </ul>
                </li>
                <li>
                    <a href="/index.php/<?= $nationlink ?>business/water" class="d1">사업소개</a>
                    <ul class="nav_sub">
                        <li><a href="/index.php/<?= $nationlink ?>business/water">식수개발개선</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>business/selfhelp">자활기술지원</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>business/medical">의료보건개선</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>business/child">아동복지개선</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>business/education">교육개발개선</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>business/culture">문화체육결연</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>business/environment">환경개발개선</a></li>
                    </ul>
                </li>
                <li>
                    <a href="/index.php/<?= $nationlink ?>news/report" class="d1">ILA소식</a>
                    <ul class="nav_sub">
                        <li><a href="/index.php/<?= $nationlink ?>news/report">현장소식</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>news/media">언론보도</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>news/notice">공지사항</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>news/download">자료실</a></li>
                    </ul>
                </li>
                <li>
                    <a href="/index.php/<?= $nationlink ?>support/regular" class="d1">후원하기</a>
                    <ul class="nav_sub">
                        <li><a href="/index.php/<?= $nationlink ?>support/regular">정기후원</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>support/onece">일시후원</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>support/special">기념일기부</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>support/legacy">유산기부</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>support/group">단체기부</a></li>
                        <li><a href="/index.php/<?= $nationlink ?>support/enterprise_intro">기업후원</a></li>
                    </ul>
                </li>
                <?/*<!--
                <li>
                    <a href="https://hwangsc.github.io/ila/html/home.html#" class="d1">나의후원</a>
                    <ul class="nav_sub">
                        <li><a href="https://hwangsc.github.io/ila/html/home.html#">회원정보</a></li>
                        <li><a href="https://hwangsc.github.io/ila/html/home.html#">후원정보</a></li>
                        <li><a href="https://hwangsc.github.io/ila/html/home.html#">기부금영수증</a></li>
                    </ul>
                </li>
                -->
                */?>
            </ul>
            <button class="btn_sponsor" onclick="ConnectSponsor();">후원하기</button>
        </div>
    </div>
</div>
<script>
function ConnectSponsor() {
    var a = document.createElement('a');
    a.href='<?php echo SUPPORT_REGULAR_URL; ?>';
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}
</script>