	</div>
</div>
<!-- //Content -->


<!-- Footer -->
<div id="footer" class="footer_wrap">
	<div class="footer_in">
		<div class="sns_area">
			<a href="https://www.youtube.com/user/IloveafricaNGO" class="ic_ut"><span class="blind">Youtube</span></a>
			<a href="https://www.facebook.com/ngoiloveafrica/" class="ic_fb"><span class="blind">FaceBook</span></a>
			<a href="https://www.instagram.com/ngoiloveafrica/" class="ic_in"><span class="blind">Instagram</span></a>
			<a href="http://blog.naver.com/iloveafrica1" class="ic_nb"><span class="blind">Naver Blog</span></a>
			<a href="https://post.naver.com/iloveafrica1" class="ic_np"><span class="blind">Naver Post</span></a>
			<a href="http://www.twitter.com/ngoiloveafrica" class="ic_tw"><span class="blind">Twitter</span></a>
		</div>
		<div class="footer_txt">
			<ul class="footer_lst">
				<li><a href="<?php echo SUPPORT_REGULAR_URL; ?>" target="_blank">후원하기</a></li>
				<li><a href="<?php echo SUPPORT_ENTERPRISE_URL; ?>" target="_blank">제휴문의</a></li>
				<li><a href="/index.php/etc/rule">이용약관</a></li>
				<li><a href="/index.php/etc/privacy">개인정보처리방침</a></li>
			</ul>
			<div class="footer_terms">
				대표전화 : 1577-1855  <span class="bar">|</span>  기업/단체문의전화 : 02-780-7111 <br />이메일 : <a href="mailto:iloveafrica1@iloveafrica.or.kr">iloveafrica1@iloveafrica.or.kr</a><br />
				<strong>사단법인아이러브아프리카 <span class="tx1">아프리카 전문</span> <span class="tx2">구제구호개발</span> <span class="tx3">비정부단체</span></strong>
			</div>
			<address>
				 대표 : 이창옥 <span class="bar">|</span> 사업자번호 : 107-82-15120<br />
				서울특별시 종로구 새문안로92,1917호(신문로1가 163, 광화문오피시아빌딩)
			</address>
		</div>
		<a href="#" class="logo_footer"><span class="blind">NGO I LOVE AFRICA</span></a>
		<p class="footer_desc">※ 본 웹사이트는 게시된 이메일 주소가 전자우편 수집 프로그램이나 그 밖의 기술적 장치를 이용하여 무단 수집되는 것을 거부합니다.
				이를 위반시 『정보통신망이용촉진 및 정보보호등에 관한법률』등에 의해 처벌 받을 수 있습니다.</p>
		<div class="footer_btn_pc">
			<a href="#">PC버전보기</a>
		</div>
	</div>
</div>
<!-- //Footer -->

</div>

<script src="/assets/js/jquery.bxslider.min.js" type="text/javascript"></script>
<script src="/assets/js/mobile/ila.js" type="text/javascript"></script>
<script>
$(document).ready(function(){
	$('.main_slider').bxSlider({
	mode:'fade',
	slideMargin: 0,
	auto: true, 
	autoHover: false, 
	controls: false
	});
});
</script>
</body>
</html>