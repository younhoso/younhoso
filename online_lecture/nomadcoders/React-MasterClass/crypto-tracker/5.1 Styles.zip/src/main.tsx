import React from "react";
import ReactDOM from "react-dom/client";
import router from "./Router";
import { RouterProvider } from "react-router-dom";
import { InitGlobalStyled } from "./styles/init";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <InitGlobalStyled />
    <RouterProvider router={router} />
  </React.StrictMode>
);
