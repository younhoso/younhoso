<div class="tab_d1">
    <ul>
        <li style="width:25%"><a href="/index.php/foundation/about">재단소개</a></li>
        <li style="width:25%"><a href="/index.php/business/water">활동</a></li>
        <li style="width:25%"><a href="/index.php/news/report">ILA소식</a></li>
        <li style="width:25%"><a href="/index.php/support/regular">후원안내</a></li>
    </ul>
</div>
